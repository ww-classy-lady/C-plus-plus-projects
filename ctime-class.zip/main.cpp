//Wendy Wu
//Purpose: experiment and test ctime package functions.
//Highlight: this short program will print the day of the week and the specific time according to UTC time zone.
#include <iostream>
#include <ctime>
#include <chrono>
using namespace std;
using namespace std::chrono;

int main() {
  cout << "Hello World!\n";
//check the current time using time_t object t
time_t t;
time(&t);
cout << time(&t) << endl;
cout <<t <<endl;
cout<<ctime(&t) <<endl; //&t = address of t
while(cin.get()!='\n')
{

}
time_t h;
time(&h);
cout << ctime(&h);
}