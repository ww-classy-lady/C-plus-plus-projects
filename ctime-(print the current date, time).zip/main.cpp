#include <iostream>
#include <ctime>
#include <chrono>
using namespace std;
using namespace std::chrono;

int main() {
  cout << "Hello World!\n";
//check the current time using time_t object t
time_t t;
time(&t);
cout << time(&t) << endl;
cout <<t <<endl;
cout<<ctime(&t) <<endl; //&t = address of t
while(cin.get()!='\n')
{

}
time_t h;
time(&h);
cout << ctime(&h);
}