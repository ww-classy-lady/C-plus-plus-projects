#include <iostream>
using namespace std;

void pause() //pause function 
{
  while(cin.get()!= '\n')
  {
    //pause?
  }
}
class Impostor; 
class Crewmate
{

  private:
  int numTasks; 
  friend bool isWin (Crewmate c, Impostor i);
  //friend the isWin function in Crewmate 
  friend int bonus(Crewmate c, Impostor i, int x, int y); //for bonus
  public:
  Crewmate(int tasks)
  {
    numTasks = tasks;
  }
  bool getKilled = false;


  int doTask()
  {
    numTasks++;
    return numTasks;
  }

};
class Impostor
{
  private:
  int numKills;
  friend bool isWin (Crewmate c, Impostor i);
  //friend the isWin function in Impostor
  friend int bonus(Crewmate c, Impostor i, int x, int y);//for bonus
  public:
  Impostor(int kills)
  {
    numKills = kills;
  }
  int kill()
  {
    numKills++;
    return numKills;
  }
};

bool isWin(Crewmate c, Impostor i)
{
  bool win = false;
  int number;
  int task = c.numTasks; //store the number of task to see if one more task is 3 (which will make crewmate win and prevent the impostor from killing the crewmate)
  srand(time(0)); //randomize the number
  number = (rand()%3)+1; //only if the output is 3 that impostor can kill crewmate

    //cout << number;
  if(c.numTasks >=3)
  {
    cout << "The Crewmate Wins!\n";
    win = true;
  }
  else if (((task+1) <3)&&number==3) // only if the next task number is less than three and that the number is 3 does the Impostor make a kill
  {
    i.kill(); 
    cout << "The Crewmate has " << (task+1) << " tasks done." << "\n";
    cout<< "The Impostor killed the Crewmate.\n";
    cout << "The Crewmate got " << c.doTask() << " tasks done before dying.\n";
    pause();
    cout << "The Impostor Wins!\n";
    win = true;
  }
  
  return win;
}
int bonus(Crewmate c, Impostor i, int x, int y)
{
  int win = 2;
  //int num=0;
  int task = c.numTasks;
  bool end = false;
  /*srand(time(0));
  num = (rand()%y)+1; //only if the output is 1 to x that impostor can kill crewmate
      //cout << "The killer number is : " <<number << endl << "\n";
  cout << num;*/
  if ((y<=x)&&((task+1) <3))
  {
    i.kill();
    c.doTask();
    //"The Impostor Wins!\n";
    win = 1;
  }
  else if(c.numTasks >=3)
  {
    //"The Crewmate Wins!\n";
    win=0;
  }
  
  return win;
}
int main() {
  bool dont = false;
 // int i = 0;
  string x = "";
  string y = "";
  int number=0; //track crewmate win
  int number2=0; //track impostor win
  int a =0;
  int b =0;
  int num = 0;
  int num2 = 0;
  double iWin = 0.00;
  double cWin = 0.00;
  int store = 2;
  int test =0;
  int easy = 0;
  bool done2 = false;
  bool stop = false;
  char random = ' ';
  cout << "Welcome to AMONG US GAME (THE SIMPLE) Version\n";
  cout << "1. AmongUs\n";
  cout << "2. Bonus\n";
  cout << "0. Exit\n";
  while(stop==false)
  {
    cin >> random;
    if(random == '1') //if the user wants to play
    {
    
        Crewmate good(0); //re declare a crewmate/impostor
        Impostor evil(0);
        bool done = false;
        srand(time(0));
        int num = (rand()%2)+1; //between 1 and 2
        int number;
        int trackTask = 0;
        if(num==1)
        {
          cout << "You are the Crewmate.\n";
          pause();
          while(done==false)
          {
            done=isWin(good,evil); //check if there's a win
              if(done==false) // if not then just keep doing task
              {
              cout << "The Crewmate has " << good.doTask() << " tasks done.\n";
              pause();
              }
          }
        }
        else
        {
            cout << "You are the Impostor.\n";
            pause();
            while(done==false)
            {
               
              done=isWin(good,evil);
              if(done==false)
              {
              cout << "The Crewmate has " << good.doTask() << " tasks done.\n";
              pause();
              }
            }
        }
      pause();
    }
  else if(random =='0')
  {
    cout << "You have exited AMONGUS...\n";
    stop = true;
    break;
  }
  else if(random=='2') //BONUS 
  { 
    int i = 0; //initialize the variable everytime the bonus runs
    number=0;
    number2=0;
    iWin = 0.0;
    cWin =0.0;
    easy = 3;
  cout << "The Impostor has a x in y chance to kill the Crewmate each round.\n";
  cout << "x: ";
  cin >> x;
  a = stoi(x); //convert from string to int
  cout << "y: ";
  cin >> y;
  b = stoi(y);
  srand(time(0));
  while(i<1000) //1000 games
  {
    Crewmate good(0);
    Impostor evil(0);
    while(done2==false)
    {
    num2 = (rand()%b)+1; //only if the output is 1 to x that imposter can kill crewmate
      //cout << "The killer number is : " <<number <<endl << "\n";*/
    easy = bonus(good,evil,a,num2); //call to the bonus method : crewmate good, impostor evil, x=a, num2 = random number within the range of 1 to y.
      if(easy==0)
      {
        number++;
        done2 = true; //win happened
      }
      else if (easy==1)
      {
        number2++;
        done2 = true; //win happened
      }  
      else if (easy ==2) //not winning so gotta do more tasks
      {
        good.doTask();
      }
    }
    i++;
    done2 = false;
  }
  cout << "\nThe number of winning games for impostor  is: " << number2;
  cout << "\nThe number of winning games for crewmate  is: " << number;
  cWin = (((double) number)/1000)*100;
  iWin = (((double) number2)/1000)*100;
  cout << "\nAfter 1000 games, the Impostor won " << iWin << " % of games and the Crewmate won " << cWin << " % of games.";
  }
  else
  {
    cout << "Not Valid, RUN the program again and read the choices please\n"; //warn the user that the input isn't valid
    stop =true;
  }
  cout << "\n1. AmongUs\n";
  cout << "2. Bonus\n";
  cout << "0. Exit\n";
  }

  return 0;

}
