#include <iostream>
#include <string>
using namespace std;

void pause()
{
  while(cin.get()!= '\n')
  {
    //pause?
  }
}
class Impostor;
class Crewmate
{

  private:
  int numTasks;
  friend bool isWin (Crewmate c, Impostor i);
  friend int bonus(Crewmate c, Impostor i, int x, int y);

  public:
  Crewmate(int tasks)
  {
    numTasks = tasks;
  }
  bool getKilled = false;


  int doTask()
  {
    numTasks++;
    return numTasks;
  }

};
class Impostor
{
  private:
  int numKills;
  friend bool isWin (Crewmate c, Impostor i);
  friend int bonus(Crewmate c, Impostor i, int x, int y);
  public:
  Impostor(int kills)
  {
    numKills = kills;
  }
  int kill()
  {
    numKills++;
    return numKills;
  }
};

int bonus(Crewmate c, Impostor i, int x, int y)
{
  int win = 2;
  //int num=0;
  int task = c.numTasks;
  bool end = false;
  /*srand(time(0));
  num = (rand()%y)+1; //only if the output is 1 to x that impostor can kill crewmate
      //cout << "The killer number is : " <<number << endl << "\n";
  cout << num;*/
  if ((y<=x)&&((task+1) <3))
  {
    i.kill();
    c.doTask();
    //"The Impostor Wins!\n";
    win = 1;
  }
  else if(c.numTasks >=3)
  {
    //"The Crewmate Wins!\n";
    win=0;
  }
  
  return win;
}

int main() {
  bool dont = false;
  int i = 0;
  string x = "";
  string y = "";
  int number=0; //track crewmate win
  int number2=0; //track impostor win
  int a =0;
  int b =0;
  int num = 0;
  double iWin = 0.00;
  double cWin = 0.00;
  int store = 2;
  int test =0;
  int easy = 0;
  bool done2 = false;
  cout << "The Impostor has a x in y chance to kill the Crewmate each round.\n";
  cout << "x: ";
  cin >> x;
  a = stoi(x);
  cout << "y: ";
  cin >> y;
  b = stoi(y);
  srand(time(0));
  while(i<1000) //1000 games
  {
    Crewmate good(0);
    Impostor evil(0);
    while(done2==false)
    {
    
    num = (rand()%b)+1; //only if the output is 1 to x that imposter can kill crewmate
      //cout << "The killer number is : " <<number <<endl << "\n";*/
    easy = bonus(good,evil,a,num);
      if(easy==0)
      {
        number++;
        done2 = true;
      }
      else if (easy==1)
      {
        number2++;
        done2 = true;
      }  
      else if (easy ==2)
      {
        good.doTask();
      }
    }
    i++;
    done2 = false;
  }
  cout << "\nThe number of winning games for impostor  is: " << number2;
  cout << "\nThe number of winning games for crewmate  is: " << number;
  cWin = (((double) number)/1000)*100;
  iWin = (((double) number2)/1000)*100;
  cout << "\nAfter 1000 games, the Impostor won " << iWin << " % of games and the Crewmate won " << cWin << " % of games.";



  return 0;

}
