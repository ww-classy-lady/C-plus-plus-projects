//Wendy Wu
//Purpose: Calculate the Newton's Square root using the formula (n = 0.5 * (n + (num/n))). The user can input the number of iterations and the input int for this operation
#include <iostream>
using namespace std;
double sqrtHAHA(int i, double num);
int main() {
  int number_of_iterations; 
  double value;
  double squareR; // the final square root value
  int response = 1; // initial response to 1 so it runs
  while (response == 1)
  {
  cout << "How many iterations do you want?\n";
  cin >> number_of_iterations;
  cout << "What is the number?\n";
  cin >> value;

  squareR = sqrtHAHA(number_of_iterations, value);
  if (squareR>=0) 
  {
  cout << "After " << number_of_iterations << " iterations, " << "the approximate square root of " << value << " is " << squareR << ".\n\n";
  }
  else //track negative numbers
  {
    cout << "After " << number_of_iterations << " iterations, " << "the approximate square root of " << value << " is " << "an error (because the number you entered might be a negative or the iteration is negative)" << ".\n\n";
  }
  cout << "Do you want to continue? Press 1 to continue and any other number key to stop \n";
  cin >> response;
  }

}

double sqrtHAHA(int i, double num) //sqrtHAHA cuz i want a unique function
{
  double n = 1.0; //sqrt0
  int round = 0; // purpose: count the iterations
  if(num<0 || i<=0)
  {
    return -1;
  }
  while (round<i) 
  {
    n = 0.5 * (n + (num/n));
    round++;
  }
  return n; // the square root (double)
}

