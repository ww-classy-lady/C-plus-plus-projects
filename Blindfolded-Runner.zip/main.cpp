//Wendy Wu
//Purpose: Run blindfolded runner horizontally or vertically (by user's choice).
//The runner's position will be displayed as X on screen and the walls are the "|" on the right and left of the screen.
//Once the "X" hits either wall, the game is over.
#include <iostream>
#include <string>
using namespace std;
void sleep()
{
  int sleep1 = 0;
  while(sleep1 < 3.14e7)
  {
    sleep1++;
  }
}
void slow()
{
  int bacon = 0;
  while(bacon < 1.5e7)
  {
    bacon++;
  }
}
int main() {
//system("clear"); // clear screen Thanks Emily!
srand(time(0)); 
bool stop;//make sure that if the runner hit a hay bale then print x and stop run()
int choice =0;
bool out = false;
char ou =' ';
//string test[11] = {"|"," "," "," "," ","+"," "," "," "," ","|"};
while(out ==false)
{
int count = 0;//count the total number of steps until hit
int pos = 5;
int posf = pos;
stop = false;
string test[11] = {"|"," "," "," "," ","+"," "," "," "," ","|"};
cout << "Welcome to Blindfolded Runner!\n";
cout << "1. Vertical Output" << endl;
cout << "2. Horizontal Output" <<endl;
cout << "Please enter your choice: \t\t";
cin >> choice;
if (choice == 1)
{
for (int o = 0; o < 11; o++)
{
  cout << test[o];
}
sleep(); //delay
cout << endl;
while(stop == false)
{
  int number = (rand()%3)+1; //1 = stay, 2 = left, 3 = right
  //cout << number << endl;
  if (number == 1) //stay
  {
    for(int h = 0; h <11; h++)
    {
      cout<< test[h];
    }
    sleep(); //delay
    cout << endl;
    count++; //one more step
  }
  else if(number ==2) // move + to left
  {
    posf = pos; //set the counting position var to pos
    if((posf-1)==0) //if gonna hit the left most wall
    {
      test[0] = "X";
      test[1] = " ";
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      sleep(); //delay
      cout <<endl;
      count++;
      stop = true; 
    }
    else //just move one to the left
    {
      posf=pos; //keep the old position in posf
      pos = pos - 1; //decrement? is this a word 
      test[pos] = "+";
      test[posf] = " ";
      posf = pos; //set posf to pos again to match but im not sure if this line is needed
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      sleep(); //delay
      cout << endl;
      count++;
    }

  }
  else //move to the right/option:3
  {
    posf = pos; //set the counting position var to pos
    if((posf+1)==10) //if gonna hit the left most wall
    {
      test[10] = "X";
      test[9] = " ";
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      sleep(); //delay
      cout <<endl;
      count++;
      stop = true; 
    }
    else //just move one to the right
    {
      posf=pos; //keep the old position in posf
      pos = pos + 1; //decrement? is this a word 
      test[pos] = "+";
      test[posf] = " ";
      posf = pos; //set posf to pos again to match but im not sure if this line is needed
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      sleep(); //delay
      cout << endl;
      count++;
    }
  }

}
cout << "Total steps taken: " << count << endl;

}
else if(choice ==2) //horizontal output
{
  //do this later probably IF I have time which is probably not really gonna happen
  //cout << "\t\t";
slow(); //delay
for (int o = 0; o < 11; o++)
{
  cout << test[o];
}
//slow(); //delay
cout << endl;
while(stop == false)
{
  int number = (rand()%3)+1; //1 = stay, 2 = left, 3 = right
  //cout << number << endl;
  if (number == 1) //stay
  {
    system("clear");
    slow(); //delay
    for(int h = 0; h <11; h++)
    {
      cout<< test[h];
    }
    //slow(); //delay
    cout << endl;
    count++; //one more step
  }
  else if(number ==2) // move + to left
  {
    system("clear");
    posf = pos; //set the counting position var to pos
    if((posf-1)==0) //if gonna hit the left most wall
    {
      test[0] = "X";
      test[1] = " ";
      slow(); //delay
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      //slow(); //delay
      cout <<endl;
      count++; //don't need to clear screen since it's the last one
      stop = true; 
    }
    else //just move one to the left
    {
      posf=pos; //keep the old position in posf
      pos = pos - 1; //decrement? is this a word 
      test[pos] = "+";
      test[posf] = " ";
      posf = pos; //set posf to pos again to match but im not sure if this line is needed
      slow(); //delay
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      //slow(); //delay
      cout << endl;
      count++;
    }

  }
  else //move to the right/option:3
  {
    system("clear");
    posf = pos; //set the counting position var to pos
    if((posf+1)==10) //if gonna hit the left most wall
    {
      test[10] = "X";
      test[9] = " ";
      slow(); //delay
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      //slow(); //delay
      cout <<endl;
      count++;
      stop = true; 
    }
    else //just move one to the right
    {
      posf=pos; //keep the old position in posf
      pos = pos + 1; //decrement? is this a word 
      test[pos] = "+";
      test[posf] = " ";
      posf = pos; //set posf to pos again to match but im not sure if this line is needed
      slow(); //delay
      for (int o = 0; o < 11; o++)
      {
        cout << test[o];
      }
      //slow(); //delay
      cout << endl;
      count++;
    }
  }

}
cout << "Total steps taken: " << count << endl;

}
else 
{
  cout << "Please enter a valid option" << endl;
}
cout << "Would you like to play again? (y/n) \t\t";
cin >> ou;
if (ou == 'y')
{
  out = false;
}
else if (ou == 'n')
{
  out = true;
}
else
{
  out = true;
  cout << "not valid so system exit automatically";
}
}
return 0;
}
