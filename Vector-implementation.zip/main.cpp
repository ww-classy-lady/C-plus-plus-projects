//Wendy Wu
//Purpose: Implement Vector (x,y,z)
//Find magnitude function is implemented to calculate the magnitude of a vector provided by the user
//Find if a component of the vector (x,y,or z) is positive or not
//Various operators are overloaded
#include <iostream>
#include <cmath>
using namespace std;
//please type in x, y ,z
class Vector 
{
private:
double X, Y, Z;

public:

Vector(double x, double y, double z) //constructor
{
  X = x;
  Y = y;
  Z = z;
}
Vector() //magnitude = 0 then all components must = 0
{
  X = 0;
  Y = 0;
  Z = 0;
}
//set functions
void setX(double n)
{
  X = n;
}
void setY(double n)
{
  Y = n;
}
void setZ(double n)
{
  Z = n;
}
//accessor functions
void print() //saves so much work to have a print function
{
  /*cout.setf(ios::fixed);
  cout.setf(ios::showpoint);
  cout.precision(2); //to 100th place */ //set in main
  cout << "< " << X << ", " << Y << ", " << Z << " >" <<endl; // prints out the vector
 
}
double getX() const//accessor functiosn to make everything easier
{
  return X;
}
double getY() const
{
  return Y;
}
double getZ() const
{
  return Z;
}
//auxiliary functions
double findMag()
{
  double x = pow(X, 2.0); //square x
  double y = pow(Y, 2.0);
  double z = pow(Z, 2.0);
  double knot = x+y+z; 
  double mag = sqrt(knot); 
  return mag;
}
bool findPos(char p) // findpos : negative, positive or zero
{
  bool cool;
  if((p=='x')||(p=='X'))
  {
    if(X>=0)
    {
      cool = true;
    }
    else
    {
      cool = false;
    }
  }
  else if((p=='y')||(p=='Y'))
  {
    if(Y>=0)
    {
      cool = true;
    }
    else
    {
      cool = false;
    }
  }
  else if((p=='z')||(p=='Z'))// Z
  {
    if(Z>=0)
    {
      cool = true;
    }
    else
    {
      cool = false;
    }
  }
  else
  {
    cout << "Please enter a valid letter for the vector component" << endl; // will never have anything other than x, y, or z but just included an else to finish off the if loops
  }
  return cool;
}
};
//overloaded operators
double operator*(const Vector &v1, const Vector &v2)
{//dot product
  double b = 0.0;
  b= (v1.getX()*v2.getX()) + (v1.getY()*v2.getY()) + (v1.getZ()*v2.getZ());
  return b;
}
Vector operator%(const Vector &v1, const Vector &v2)
{
  double x = (v1.getY()*v2.getZ()) - (v1.getZ()*v2.getY()); //first get the x component of the dot product by yz1 - zy1
  double y = (v1.getX()*v2.getZ()) - (v1.getZ()*v2.getX()); // get the y component of the dot product by xz1 - zx1
  if(y!=0) //prevent -0.00 
  {
  y = y*-1; // -j
  }
  double z = (v1.getX()*v2.getY()) - (v1.getY()*v2.getX()); // get the z component of the dot product by xy1 - yx1
  return Vector{x, y, z};
}
Vector operator-(const Vector &v1) // return a negative vector (flip signs)
{
  Vector turn{};
  turn.setX(-v1.getX());
  turn.setY(-v1.getY());
  turn.setZ(-v1.getZ());
  return turn;
}
Vector operator+(const Vector &v1, const Vector &v2)
{
  return Vector{v1.getX()+v2.getX(), v1.getY()+v2.getY(), v1.getZ()+v2.getZ()};
 //return the vector after addition
}
Vector operator-(const Vector &v1, const Vector &v2)
{
  return Vector{v1.getX()-v2.getX(), v1.getY()-v2.getY(), v1.getZ()-v2.getZ()};
}

//main function/menu
int main() {
  cout.setf(ios::fixed);
  cout.setf(ios::showpoint);
  cout.precision(2); //to 100th place
  cout << "what is a vector...hmmm\n";
  cout << "Anyways, WELCOME TO VECTORS" << endl;
  bool stop = false; // variable to track if the menu should stop or not
  int option;
  double x,y,z;
  double x1,y1,z1,x2,y2,z2;
  char comp = ' ';
  while(stop==false)
  {
    cout << "Menu\n\n" <<endl;
    cout << "1. The - unary operator" <<endl;
    cout << "2. The + operator" << endl;
    cout << "3. The - operator" <<endl;
    cout << "4. The * operator" <<endl;
    cout << "5. The % operator" <<endl;
    cout << "6. findMag()" <<endl;
    cout << "7. findPos()" <<endl;
    cout << "0. Quit" << endl;
    cout << "Please enter your choice: ";
    cin >> option;
    cout << "\n\n";
    if(option == 1) //flip signs
    {
      cout << "-V1" <<endl;
      cout << "Enter X1: ";
      cin >>x;
      cout << "Enter Y1: ";
      cin >>y;
      cout << "Enter Z1: ";
      cin >>z;
      cout <<endl;
      Vector micro{x,y,z};
      Vector wave{-micro}; //call to the unary - operator
      cout << "-V = " ;
      wave.print();
      cout << endl<<"\n" ;
    }
    else if (option ==2) //addition
    {
      cout << "Addition V1 + V2" <<endl;
      cout << "Enter X1: ";
      cin >> x1;
      cout << "Enter Y1: ";
      cin >> y1;
      cout << "Enter Z1: ";
      cin >> z1;
      cout << "Enter X2: ";
      cin >> x2;
      cout << "Enter Y2: ";
      cin >> y2;
      cout << "Enter Z2: ";
      cin >> z2;
      cout <<endl;
      Vector cream{x1,y1,z1};
      Vector heroes{x2,y2,z2};
      Vector cat{cream + heroes}; //call to the + operator
      cout << "V1 + V2 = ";
      cat.print();
      cout << endl<<"\n" ;

    }
    else if (option ==3) //subtraction -
    {
      cout << "Subtraction V1 - V2 "<< endl;
      cout << "Enter X1: ";
      cin >> x1;
      cout << "Enter Y1: ";
      cin >> y1;
      cout << "Enter Z1: ";
      cin >> z1;
      cout << "Enter X2: ";
      cin >> x2;
      cout << "Enter Y2: ";
      cin >> y2;
      cout << "Enter Z2: ";
      cin >> z2;
      cout <<endl;
      Vector kitti{x1,y1,z1};
      Vector saurus{x2,y2,z2};
      Vector dd{kitti - saurus}; //call to the - operator
      cout << "V1 - V2 = ";
      dd.print();
      cout << endl<<"\n" ;
    }
    else if (option ==4) //dot product
    { 
      cout << "Dot Product V1 * V2 "<< endl;
      cout << "Enter X1: ";
      cin >> x1;
      cout << "Enter Y1: ";
      cin >> y1;
      cout << "Enter Z1: ";
      cin >> z1;
      cout << "Enter X2: ";
      cin >> x2;
      cout << "Enter Y2: ";
      cin >> y2;
      cout << "Enter Z2: ";
      cin >> z2;
      cout <<endl;
      Vector holst{x1,y1,z1}; 
      Vector mars{x2,y2,z2}; 
      cout << "V1 * V2 = " << holst*mars; //call to * dot product
      cout << endl<<"\n" ;
      
    }
    else if (option ==5)
    {
      cout << "Cross Product V1 X V2 "<< endl;
      cout << "Enter X1: ";
      cin >> x1;
      cout << "Enter Y1: ";
      cin >> y1;
      cout << "Enter Z1: ";
      cin >> z1;
      cout << "Enter X2: ";
      cin >> x2;
      cout << "Enter Y2: ";
      cin >> y2;
      cout << "Enter Z2: ";
      cin >> z2;
      cout <<endl;
      Vector claire{x1,y1,z1};
      Vector tt{x2,y2,z2};
      Vector elgar{claire%tt}; //elgar the dark themed composer...anyways call to the % operator for cross product
      cout << "V1 X V2 = ";
      elgar.print();
      cout << endl<<"\n" ;
    }
    else if (option ==6)
    { //findMag
      cout << "Magnitude of V1" <<endl;
      cout << "Enter X1: ";
      cin >> x;
      cout << "Enter Y1: ";
      cin >> y;
      cout << "Enter Z1: ";
      cin >> z;
      cout <<endl;
      Vector serenade{x,y,z};
      cout << "Magnitude: " << serenade.findMag() << endl << "\n";
    }
    else if (option ==7)
    { //findPos
      bool neptune;
      cout << "findPos() " <<endl;
      cout << "Enter X1: ";
      cin >> x;
      cout << "Enter Y1: ";
      cin >> y;
      cout << "Enter Z1: ";
      cin >> z;
      cout <<endl;
      Vector planets{x,y,z};
      cout << "Which component would you like to check?  ";
      cin >> comp;
      cout << "\n";
      neptune = planets.findPos(comp); //call to findPos
      if(neptune == false)
      {
        cout << "The component returned false and is negative" <<endl;
      }
      else
      {
        cout << "The component returned true and is positive or zero" <<endl;
      }
      cout << "\n\n";
    }
    else if (option ==0)
    {
      stop =true; //when enter the option quit then stop the loops
    }
    else
    {
      cout << "Please enter a valid choice. "<< endl;
    }

  }
//the end
  cout << "Au revoir...Sayōnara...Goodbye" << endl;
}