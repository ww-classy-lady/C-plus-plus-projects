//Wendy Wu
//Purpose: implement a Hazard dice game algorithm to allow the player to roll two dice and report the outcome to see whether the player wins or lose. The total games played, number of wins on the first roll, number of losses on the first roll, number of wins NOT on the first roll, and the number of losses NOT on the first roll is reported in the results, and the user can choose to see it while the program is active.
#include <iostream>
using namespace std;

//the pause and delay should allow user to press enter to continue

struct result
{
  int numGames; // the number of total games played
  int winFirst; //the number of wins on the first roll
  int lossFirst; // the number of losses on the first roll
  int numWins; //the number of wins not on first roll
  int numLoss; //the number of losses not on first roll
  int numRoll;
  bool keepRoll; //keep going if neither win or lose
  bool check; //give user option to check result.
  bool response; //decide if user wants to check response and direct to the report function
  int main;
};

void pause() //pause method
{
  while(cin.get()!= '\n')
  {
    //doesn't do anything so just "pause" the system but I'll just keep this here.

  }
  
}

void hazard(result& theOne);
void hazard(result& theOne)
{
  int dice1 = (rand()%6)+1;
  int dice2 = (rand()%6)+1;
  int sum = dice1 + dice2;
  theOne.numRoll =theOne.numRoll+1;
  cout << "The main is : " <<  theOne.main << "     \n";
  pause();
  cout << "\nYou rolled a " << dice1 << " + " << dice2 << " = " << sum << "    \n";
  pause();
  if(sum==theOne.main) //win by rolliung the same number as main
  {
    //win 
    if(theOne.numRoll==1)
    {
      theOne.winFirst = theOne.winFirst +1; //+1 to win on first toll
      cout << "You rolled the main (on the first roll), you win!\n";
      theOne.keepRoll = false;
      pause();
    }
    else //win but not on first toll
    {
      theOne.numWins = theOne.numWins +1;
      cout << "You rolled the main (not on the first roll), you win!\n";
      theOne.keepRoll = false;
      pause();
    }
  //should pause here
  }
  else if (sum==2||sum==3) //lose if rolled a 2 or 3
  {
    //lose
    if(theOne.numRoll==1)
    {
      theOne.lossFirst= theOne.lossFirst +1; //+1 to lose on first toll
      cout << "You rolled a 2 or 3 (on the first roll), you lose!\n";
      theOne.keepRoll = false;
      pause();
    }
    else //lose but not on first toll
    {
     theOne.numLoss = theOne.numLoss +1;
     cout << "You rolled a 2 or 3 (not on the first roll), you lose!\n";
     theOne.keepRoll = false;
     pause();
    }
    //should pause here
  }
  else if (sum==11||sum==12) //this is very longggg
  {
    if(theOne.main==5||theOne.main==9)
    {
      if(theOne.numRoll==1)
      {
        theOne.lossFirst= theOne.lossFirst +1; //+1 to loss in the first toll
        cout << "You rolled 11 or 12 (on the first roll), you lose!\n";
        theOne.keepRoll = false;
        pause();
      }
      else //lose but not on first toll
      {
        theOne.numLoss = theOne.numLoss +1;
        cout << "You rolled 11 or 12 (not on the first roll), you lose!\n";
        theOne.keepRoll = false;
        pause();
      }
      //should pause here/exit this program
    }
    else if (theOne.main==6||theOne.main==8)
    {
       if(sum==11) //lose
       {
           if(theOne.numRoll==1)
           {
              theOne.lossFirst= theOne.lossFirst +1; //+1 to loss in the first toll
              cout << "You rolled an 11 (on the first roll), you lose!\n";
              theOne.keepRoll = false;
              pause();
           }
           else //lose but not on first toll
           {
              theOne.numLoss = theOne.numLoss +1;
              cout << "You rolled an 11 (not on the first roll), you lose!\n";
              theOne.keepRoll = false;
              pause();
           }
            //should pause here/exit this program
       }
       else //only option: sum =12 and wins
       {
            if(theOne.numRoll==1)
            {
              theOne.winFirst = theOne.winFirst +1; //+1 to win on first toll
              cout << "You rolled a 12 (on the first roll), you win!\n";
              theOne.keepRoll = false;
              pause();
            }
            else //win but not on first toll
            {
              theOne.numWins = theOne.numWins +1;
              cout << "You rolled a 12 (not on the first roll), you win!\n";
              theOne.keepRoll = false;
              pause();
            }
            //return to main menu
       }
    }
    else if(theOne.main==7)
    {
      if(sum==11) //wims
      {
          if(theOne.numRoll==1)
          {
            theOne.winFirst = theOne.winFirst +1; //+1 to win on first toll
            cout << "You rolled an 11 (on the first roll), you win!\n";
            theOne.keepRoll = false;
            pause();
          }
          else //win but not on first toll
          {
            theOne.numWins = theOne.numWins +1;
            cout << "You rolled an 11 (not on the first roll), you win!\n";
            theOne.keepRoll = false;
            pause();
          }
          //pause/exit
      }
      else //sum = 12 and loses
      {
          if(theOne.numGames==1)
           {
              theOne.lossFirst= theOne.lossFirst +1; //+1 to loss in the first toll
              cout << "You rolled a 12 (on the first roll), you lose!\n";
              theOne.keepRoll = false;
              pause();
           }
           else //lose but not on first toll
           {
              theOne.numLoss = theOne.numLoss +1;
              cout << "You rolled a 12 (not on the first roll), you lose!\n";
              theOne.keepRoll = false;
              pause();
           }
            //should pause here/exit this program
      }
      
    }
  }
  else
  {
    theOne.numRoll = theOne.numRoll+1; //increment the number of rolls if didn't win or lose
    cout << "\nYou have to roll again\n";
    theOne.check = true;

   // pause/exit and roll again.
  }

}

void report(result& theOne);
void report(result& theOne)
{
  cout << "The number of total games played is:  " << theOne.numGames <<endl;
  cout << "The number of wins on the first roll is:  " << theOne.winFirst <<endl;
  cout << "The number of losses on the first roll is:  " << theOne.lossFirst <<endl;
  cout << "The number of wins NOT on the first roll is :  " << theOne.numWins <<endl;
  cout << "The number of losses NOT on the first roll is  " << theOne.numLoss <<endl;
  cout << "\n\n";

}
void reset(result& theOne);
void reset(result& theOne)
{
  theOne.numGames = 0;
  theOne.winFirst = 0;
  theOne.lossFirst =0;
  theOne.numWins =0;
  theOne.numLoss =0;
}
int main() //the menu
{
 result theOne;
 theOne.numGames = 0;
 theOne.winFirst = 0;
 theOne.lossFirst =0;
 theOne.numWins =0;
 theOne.numLoss =0;
 theOne.numRoll = 0; //initialize the numnber of rolls
 theOne.main = 0; //from 5 to 9 inclusive
 theOne.keepRoll = true;
 int choice=0;
 theOne.check = false; //initialize check to false so if in hazard said have to roll again then check = true and allow for the report option to be displayed.
char decision = ' ';
while(choice!=4)
{
  cout << "\n\nWelcome to HAZARD! This is the menu:\n" << "1.Play Hazard\n" << "2.Report results\n" << "3.Reset results\n" << "4.Exit\n" << "\nPlease enter your Choice: ";
  cin >> choice;
  if(choice ==1)
  {
    theOne.keepRoll = true;
    srand(time(0));
    theOne.main = (rand()%5)+5; //set a new main
    cout << "\n\nGame: Hazard\n";
    while(theOne.keepRoll==true) 
    {
      hazard(theOne);
    
    if(theOne.check == true) //yes have to roll again but give the report option.
    {
      cout << "\nWould you like to see your results? 'y' or 'Y' for yes and press any other letter keys for no \n";
      cin >> decision;
      if((decision== 'y')||(decision == 'Y'))
      {
        report(theOne);
        theOne.check = false;
      }
      else
      {
        theOne.check =false;
      }
    }
    }
    if(theOne.keepRoll==false)
    {
      theOne.numGames = theOne.numGames+1;
      srand(time(0));
      theOne.main = (rand()%5)+5; //set a new main
      theOne.numRoll =0;
    }
  }
  else if (choice ==2)
  {
    cout << "\n\nThis is a report of the number of total games, wins, and losses\n\n";
    report(theOne);
  }
  else if (choice ==3)
  {
    cout << "\n\nThis is a reset of all data \n\n";
    reset(theOne);
  }
  else //basically exit game
  {
  }
}

 
 
return 0;
}

